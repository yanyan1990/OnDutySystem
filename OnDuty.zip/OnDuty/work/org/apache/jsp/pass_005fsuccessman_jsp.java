package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class pass_005fsuccessman_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script>  \r\n");
      out.write("<body>\r\n");

Connection conn=Connectionsql.connsql();
String mnum=request.getParameter("mnum");
String username=request.getParameter("username");
String oldpass=request.getParameter("oldpass");
String newpass=request.getParameter("newpass");
newpass=newpass.trim();
String checkpass=request.getParameter("checkpass");
checkpass=checkpass.trim();
PreparedStatement pStmt2=null;
int rtn=0;
pStmt2=conn.prepareStatement("UPDATE [User] SET U_password=? WHERE U_name=? AND U_password=?");    
pStmt2.setString(1,newpass);
pStmt2.setString(2,username);
pStmt2.setString(3,oldpass);
if(newpass.equals(checkpass)){
	
	rtn=pStmt2.executeUpdate();
}

      out.write("\r\n");
      out.write("<div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">修改密码</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\" onclick=\"window.open(this.href); return false\"><img src=\"images/cata-launch.jpg\" alt=\"TITLE01\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
 
if(rtn>0){

      out.write("\r\n");
      out.write("<h3>修改成功！请重新<a href=\"Login.jsp\">登陆</a></h3>\r\n");
 }
else 
{

      out.write("\r\n");
      out.write("<h3>修改失败！请<a href=\"pass_checkman.jsp?&mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>\r\n");
 }
      out.write("\r\n");
      out.write("<br>   \r\n");
      out.write("<h3><a href=\"Login.jsp\">退出</a></h3>                       \r\n");
      out.write("        <div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                            \r\n");
      out.write("     </dl>\r\n");
      out.write("    \r\n");
      out.write("    <script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
 
pStmt2.close();
Connectionsql.closesql(conn);

      out.write("\r\n");
      out.write("\t\t\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
