package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class login_005fcheck_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<body>\r\n");

Connection conn=Connectionsql.connsql();
request.setCharacterEncoding("GB2312");
String usern=request.getParameter("user");
String passw=request.getParameter("userpass");
String lim=request.getParameter("limit");
boolean flag=false;
String manager=null;
String mnum=null;
String employee=null;
String empnum=null;
PreparedStatement pStmt=conn.prepareStatement("select W_number from [User] where U_name=? AND U_password=? AND U_limit=?");    
pStmt.setString(1,usern);
pStmt.setString(2,passw);
pStmt.setString(3,lim);
ResultSet rs=pStmt.executeQuery();
while(rs.next()){
if(lim.equals("manager")){
	mnum=rs.getString(1);
	flag=true;
}
else if(lim.equals("employee")){
	empnum=rs.getString(1);
	flag=true;
}
}
rs.close();
pStmt.close();
Connectionsql.closesql(conn);
if(flag&&lim.equals("manager")){

      out.write('\r');
      out.write('\n');
      if (true) {
        _jspx_page_context.forward("Managerindex.jsp" + (("Managerindex.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("mnum", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(mnum), request.getCharacterEncoding()));
        return;
      }
      out.write('\r');
      out.write('\n');
} 
else if(flag&&lim.equals("employee")){

      out.write('\r');
      out.write('\n');
      if (true) {
        _jspx_page_context.forward("Employeeindex.jsp" + (("Employeeindex.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("empnum", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(empnum), request.getCharacterEncoding()));
        return;
      }
      out.write('\r');
      out.write('\n');
 
}else{
	
      out.write('\r');
      out.write('\n');
      if (true) {
        _jspx_page_context.forward("login_failure.htm");
        return;
      }
      out.write('\r');
      out.write('\n');

}

      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
