package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class deletesuccess_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script>  \r\n");
      out.write("<body>\r\n");
      out.write("<div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">修改员工信息</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\" onclick=\"window.open(this.href); return false\"><img src=\"images/cata-launch.jpg\" alt=\"TITLE01\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");

Connection conn=Connectionsql.connsql();
String mnum=request.getParameter("mnum");
String enumber=request.getParameter("empinfonum");
String edate=request.getParameter("date");
String eduty=request.getParameter("duty");
//String sql=null;

int rtn1=0,rtn2=0,rtn3=0,rtn4=0;
PreparedStatement pStmt1=conn.prepareStatement("delete from [Attendence] where W_number=? AND A_time=?");    
pStmt1.setString(1,enumber);
pStmt1.setString(2,edate);
rtn1=pStmt1.executeUpdate();
PreparedStatement pStmt2=conn.prepareStatement("delete from [Overtimes] where W_number=? AND O_date=?");    
pStmt2.setString(1,enumber);
pStmt2.setString(2,edate);
rtn2=pStmt2.executeUpdate();
PreparedStatement pStmt3=conn.prepareStatement("delete from [Errand] where W_number=? AND E_start=?");    
pStmt3.setString(1,enumber);
pStmt3.setString(2,edate);
rtn3=pStmt3.executeUpdate();
PreparedStatement pStmt4=conn.prepareStatement("delete from [Leave] where W_number=? AND L_start=?");    
pStmt4.setString(1,enumber);
pStmt4.setString(2,edate);
rtn4=pStmt4.executeUpdate();

if(rtn1>0||rtn2>0||rtn3>0||rtn4>0){

      out.write("\r\n");
      out.write("\t<h3>删除成功！<a href=\"Managerindex.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>\r\n");
      out.write("\r\n");
}else{
      out.write("\r\n");
      out.write("\t<h3>删除失败！<a href=\"Managerindex.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>\r\n");
      out.write("\r\n");
 }

      out.write("                \r\n");
      out.write("        <div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                            \r\n");
      out.write("</dl>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");

pStmt1.close();
pStmt2.close();
pStmt3.close();
pStmt4.close();
Connectionsql.closesql(conn);

      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("\t\t\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
