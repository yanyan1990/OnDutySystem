package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class Managerindex_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>经理登陆 </title>\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script>  \r\n");
      out.write("\r\n");
      out.write("<body>\r\n");

Connection conn=Connectionsql.connsql();
request.setCharacterEncoding("GB2312");
String mnum=request.getParameter("mnum");
PreparedStatement pStmt=conn.prepareStatement("select W_name from [Worker] where W_number=?");    
pStmt.setString(1,mnum);
ResultSet rs=pStmt.executeQuery();
String managername=null;
while(rs.next()){
managername=rs.getString(1);
}

      out.write("\r\n");
      out.write("    <div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">欢迎登陆界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("              <marquee behavior=alternate width=\"500\" ><h1>欢迎<font face=楷体 color=\"lightgreen\">经理</font><font face=楷体 color=\"yellow\">");
      out.print(managername );
      out.write("</font>登陆！</h1></marquee>\r\n");
      out.write("        <div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                            \r\n");
      out.write("    \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">基本信息界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/101208.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            \r\n");
      out.write("            <h3><a href=\"depinfo.jsp?mnum=");
      out.print(mnum );
      out.write("\">部门信息</a></h3>\r\n");
      out.write("            <h3><a href=\"depeeinfo.jsp?mnum=");
      out.print(mnum );
      out.write("\">员工信息</a></h3>\r\n");
      out.write("            \r\n");
      out.write("        </div>\r\n");
      out.write("        </dd> \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">出勤信息界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/101208.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"onduty.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询出勤信息</a></h3>\r\n");
      out.write("            <h3><a href=\"onextra.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询加班信息</a></h3>\r\n");
      out.write("            <h3><a href=\"onabsence.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询请假信息</a></h3>\r\n");
      out.write("            <h3><a href=\"onbusiness.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询出差信息</a></h3>\r\n");
      out.write("            <h3><a href=\"onday.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询某日考勤</a></h3>\r\n");
      out.write("            <h3><a href=\"onmonth.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询某月考勤</a></h3>\r\n");
      out.write("            <h3><a href=\"ondayabs.jsp?mnum=");
      out.print(mnum );
      out.write("\">查询某日缺勤</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>   \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">法定假日界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/101208.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"holidayman.jsp?num=");
      out.print(mnum );
      out.write("\">查询节假日</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                        \r\n");
      out.write("        \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">修改密码界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/101208.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"pass_checkman.jsp?mnum=");
      out.print(mnum);
      out.write("\">修改密码</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                                                                        \r\n");
      out.write("    \r\n");
      out.write("        <dt>\r\n");
      out.write("               <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("               <span class=\"title\">返回登录界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\" onclick=\"window.open(this.href); return false\"><img src=\"images/101206.jpg\" alt=\"TITLE04\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"Login.jsp\">退出</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                            \r\n");
      out.write("\t</dl>\r\n");
      out.write("    \r\n");
      out.write("    <script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
