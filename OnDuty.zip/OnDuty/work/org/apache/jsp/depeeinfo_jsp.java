package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class depeeinfo_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script> \r\n");
      out.write("<body>\r\n");

Connection conn=Connectionsql.connsql();
String mnum=request.getParameter("mnum");
PreparedStatement pStmt=conn.prepareStatement("select * from [Worker] where W_Deptnum=?");    
//PreparedStatement pStmt=conn.prepareStatement("select * from [Worker] where W_Deptnum=?");    
pStmt.setString(1,mnum);
ResultSet rs=pStmt.executeQuery();

      out.write("\r\n");
      out.write("<div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">员工信息</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("<table border=\"1\" width=\"450\" rules=\"rows\" cellspacing=\"0\" cellpadding=\"0\" style=\"margin-left:100\">\r\n");
      out.write("<tr height=\"30\" align=\"center\" bgcolor=\"skyblue\">\r\n");
      out.write("<td>职工编号</td>\r\n");
      out.write("<td>职工姓名</td>\r\n");
      out.write("<td>职工性别</td>\r\n");
      out.write("</tr>\r\n");
 while(rs.next()){
      out.write("\r\n");
      out.write("<tr height=\"30\" align=\"center\">\r\n");
      out.write("<td>");
      out.print(rs.getString(1) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs.getString(2) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs.getString(3) );
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
}
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("<br>   \r\n");
      out.write("<h3><a href=\"Managerindex.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>                       \r\n");
      out.write("</dl>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");
 rs.close();
pStmt.close();
Connectionsql.closesql(conn);

      out.write("\r\n");
      out.write("</body>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
