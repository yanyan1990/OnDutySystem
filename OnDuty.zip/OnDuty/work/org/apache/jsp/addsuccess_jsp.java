package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class addsuccess_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script>  \r\n");
      out.write("<body>\r\n");
      out.write("<div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">添加员工信息</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\" onclick=\"window.open(this.href); return false\"><img src=\"images/cata-launch.jpg\" alt=\"TITLE01\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");

Connection conn=Connectionsql.connsql();
String mnum=request.getParameter("mnum");
String enumber=request.getParameter("empinfonum");
String year=request.getParameter("year");
String month=request.getParameter("month");
String day=request.getParameter("day");
String edate=year.trim()+"-"+month.trim()+"-"+day.trim();
String emonth=year.trim()+"-"+month.trim();
String eduty=request.getParameter("duty");
//String sql=null;
PreparedStatement pStmt1=null;
int rtn=0;
try{
if(eduty.equals("1")){
	//sql="insert into Attendence W_number,A_inout,A_time values(enumber,'正常',edate)";
    pStmt1=conn.prepareStatement("insert into [Attendence] (W_number,A_inout,A_time,A_month) values(?,'正常',?,?)");    
	pStmt1.setString(1,enumber);
	pStmt1.setString(2,edate);
	pStmt1.setString(3,emonth);
	rtn=pStmt1.executeUpdate();
}
else if(eduty.equals("2")){
	//sql="insert into Leave W_number,L_reason,L_start,L_end values(enumber,'请假',edate,edate)";
	pStmt1=conn.prepareStatement("insert into [Leave] (W_number,L_reason,L_start,L_end,L_month) values(?,'请假',?,?,?)");    
	pStmt1.setString(1,enumber);
	pStmt1.setString(2,edate);
	pStmt1.setString(3,edate);
	pStmt1.setString(4,emonth);
	rtn=pStmt1.executeUpdate();
}
else if(eduty.equals("3")){
	//sql="insert into Overtimes W_number,O_description,O_date,O_hour values(enumber,'加班',edate,'3')";
	pStmt1=conn.prepareStatement("insert into [Overtimes] (W_number,O_description,O_date,O_hour,O_month) values(?,'加班',?,'3',?)");    
	pStmt1.setString(1,enumber);
	pStmt1.setString(2,edate);
	pStmt1.setString(3,emonth);
	rtn=pStmt1.executeUpdate();
}
else if(eduty.equals("4")){
	//sql="insert into Errand W_number,E_description,E_start,E_end values(enumber,'出差',edate,edate)";
	pStmt1=conn.prepareStatement("insert into [Errand] (W_number,E_description,E_start,E_end,E_month) values(?,'出差',?,?,?)");    
	pStmt1.setString(1,enumber);
	pStmt1.setString(2,edate);
	pStmt1.setString(3,edate);
	pStmt1.setString(4,emonth);
	rtn=pStmt1.executeUpdate();
}
}catch(Exception e){
      out.write("\r\n");
      out.write("<h3>添加失败！<a href=\"Managerindex.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>\r\n");
} 
if(rtn>0){

      out.write("\r\n");
      out.write("\t<h3>添加成功！<a href=\"Managerindex.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>\r\n");
      out.write("\r\n");
//}else{
      out.write("\r\n");
      out.write("\t<!--<h3>添加失败！<a href=\"Managerindex.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>-->\r\n");
 }
      out.write("                      \r\n");
      out.write("        <div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                            \r\n");
      out.write("</dl>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");
 	
pStmt1.close();
Connectionsql.closesql(conn);

      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("\t\t\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
