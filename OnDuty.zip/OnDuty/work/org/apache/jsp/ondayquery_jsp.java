package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class ondayquery_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script>  \r\n");
      out.write("<body>\r\n");

Connection conn=Connectionsql.connsql();
String mnum=request.getParameter("mnum");
String date=request.getParameter("date");
PreparedStatement pStmt1=conn.prepareStatement("select Attendence.W_number,Worker.W_name,Attendence.A_inout,Attendence.A_time from [Attendence],[Worker] where Worker.W_Deptnum=? AND Worker.W_number=Attendence.W_number AND Attendence.A_time=?");    
pStmt1.setString(1,mnum);
pStmt1.setString(2,date);
ResultSet rs1=pStmt1.executeQuery();
PreparedStatement pStmt2=conn.prepareStatement("select Errand.W_number,Worker.W_name,Errand.E_description,Errand.E_start from [Errand],[Worker] where Worker.W_Deptnum=? AND Worker.W_number=Errand.W_number AND Errand.E_start=?");    
pStmt2.setString(1,mnum);
pStmt2.setString(2,date);
ResultSet rs2=pStmt2.executeQuery();
PreparedStatement pStmt3=conn.prepareStatement("select Overtimes.W_number,Worker.W_name,Overtimes.O_description,Overtimes.O_date from [Overtimes],[Worker] where Worker.W_Deptnum=? AND Worker.W_number=Overtimes.W_number AND Overtimes.O_date=?");    
pStmt3.setString(1,mnum);
pStmt3.setString(2,date);
ResultSet rs3=pStmt3.executeQuery();
PreparedStatement pStmt4=conn.prepareStatement("select Leave.W_number,Worker.W_name,Leave.L_reason,Leave.L_start from [Leave],[Worker] where Worker.W_Deptnum=? AND Worker.W_number=Leave.W_number AND Leave.L_start=?");    
pStmt4.setString(1,mnum);
pStmt4.setString(2,date);
ResultSet rs4=pStmt4.executeQuery();

      out.write("\r\n");
      out.write("<div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">查询某日考勤信息</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("<table border=\"1\" width=\"450\" rules=\"rows\" cellspacing=\"0\" cellpadding=\"0\" style=\"margin-left:100\">\r\n");
      out.write("<tr height=\"30\" align=\"center\" bgcolor=\"skyblue\">\r\n");
      out.write("<td>职工编号</td>\r\n");
      out.write("<td>职工姓名</td>\r\n");
      out.write("<td>考勤情况</td>\r\n");
      out.write("<td>考勤时间</td>\r\n");
      out.write("</tr>\r\n");
 while(rs1.next()){ 
      out.write("\r\n");
      out.write("<tr height=\"30\" align=\"center\">\r\n");
      out.write("<td>");
      out.print(rs1.getString(1) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs1.getString(2) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs1.getString(3) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs1.getString(4) );
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
} 
 while(rs2.next()){ 
      out.write("\r\n");
      out.write("<tr height=\"30\" align=\"center\" >\r\n");
      out.write("<td>");
      out.print(rs2.getString(1) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs2.getString(2) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs2.getString(3) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs2.getString(4) );
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
} 
 while(rs3.next()){ 
      out.write("\r\n");
      out.write("<tr height=\"30\" align=\"center\" >\r\n");
      out.write("<td>");
      out.print(rs3.getString(1) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs3.getString(2) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs3.getString(3) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs3.getString(4) );
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
} 
 while(rs4.next()){ 
      out.write("\r\n");
      out.write("<tr height=\"30\" align=\"center\" >\r\n");
      out.write("<td>");
      out.print(rs4.getString(1) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs4.getString(2) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs4.getString(3) );
      out.write("</td>\r\n");
      out.write("<td>");
      out.print(rs4.getString(4) );
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
} 
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("<br>\r\n");
      out.write("<h3><a href=\"onday.jsp?mnum=");
      out.print(mnum );
      out.write("\">返回</a></h3>\r\n");
      out.write("</dl>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");
 
rs1.close();
rs2.close();
rs3.close();
rs4.close();
pStmt1.close();
pStmt2.close();
pStmt3.close();
pStmt4.close();
Connectionsql.closesql(conn);

      out.write("\r\n");
      out.write("</body>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
