package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.sql.*;
import Connbean.Connectionsql;

public final class Employeeindex_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>员工登陆 </title>\r\n");
      out.write("</head>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/index.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/slider.js\"></script>  \r\n");
      out.write("<body>\r\n");

Connection conn=Connectionsql.connsql();
request.setCharacterEncoding("GB2312");
String empnum=request.getParameter("empnum");
PreparedStatement pStmt=conn.prepareStatement("select W_name from [Worker] where W_number=?");    
pStmt.setString(1,empnum);
ResultSet rs=pStmt.executeQuery();
String employeename=null;
while(rs.next()){
employeename=rs.getString(1);
}

      out.write("\r\n");
      out.write("    <div id=\"col\">\r\n");
      out.write("    <dl class=\"sliderbox\" id=\"slider2\">                        \r\n");
      out.write("        \r\n");
      out.write("        <dt class=\"open\">\r\n");
      out.write("               <span class=\"date\">Today</span>\r\n");
      out.write("               <span class=\"title\">欢迎登陆界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("              <marquee behavior=alternate width=\"500\" ><h1>欢迎<font face=楷体 color=\"lightgreen\">员工</font><font face=楷体 color=\"yellow\">");
      out.print(employeename );
      out.write("</font>登陆！</h1></marquee>\r\n");
      out.write("        <div>\r\n");
      out.write("        <h4><font face=仿宋>&nbsp;&nbsp;&nbsp;&nbsp;为进一步加强公司管理，维护正常的工作秩序，提高劳动效率，根据国家及上级部门的有关规定，结合公司实际，加强公司考勤管理，\r\n");
      out.write("                     提高员工遵章守法的自觉性，特制订本考勤管理制度，本考勤管理制度为公司重要的管理制度之一（详情见列表一）。</font></h4>\r\n");
      out.write("        </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd> \r\n");
      out.write("        \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">考勤制度界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h4><font face=楷体 >一、工作时间：员工每周工作时间为六天，每天八个小时：<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;上午 <font face=宋体> 8:00-12:00</font> &nbsp;&nbsp;&nbsp;下午 <font face=宋体>  14:00-18:00</font>\r\n");
      out.write("            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;公司可根据实际需要调整作息时间，具体情况以通知为准。 二、节假日、请假、加班、出差及缺勤等按规章制度进行执行。<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"red\">请各部门\r\n");
      out.write("            人员严格执行考勤管理规章制度，本制度自公布<br>之日起实施。</font></h4> \r\n");
      out.write("        </div>\r\n");
      out.write("        </dd> \r\n");
      out.write("                               \r\n");
      out.write("    \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">基本信息界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/cat.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"employeeinfo.jsp?empnum=");
      out.print(empnum );
      out.write("\">基本信息查询</a></h3> \r\n");
      out.write("        </div>\r\n");
      out.write("        </dd> \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">出勤信息界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/cat.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"empdayinfo.jsp?empnum=");
      out.print(empnum );
      out.write("\">查询某日考勤信息</a></h3>\r\n");
      out.write("            <h3><a href=\"empmonthinfo.jsp?empnum=");
      out.print(empnum );
      out.write("\">查询某月考勤信息</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>   \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">法定假日界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/cat.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"holidayemp.jsp?num=");
      out.print(empnum );
      out.write("\">查询节假日</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                        \r\n");
      out.write("        \r\n");
      out.write("        <dt>\r\n");
      out.write("                <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("                <span class=\"title\">修改密码界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\"><img src=\"images/cat.jpg\" alt=\"TITLE02\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"pass_checkemp.jsp?empnum=");
      out.print(empnum);
      out.write("\">修改密码</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                                                                        \r\n");
      out.write("    \r\n");
      out.write("        <dt>\r\n");
      out.write("               <span class=\"date\">July 6, 2011</span>\r\n");
      out.write("               <span class=\"title\">返回登录界面</span>\r\n");
      out.write("        </dt>\r\n");
      out.write("        \r\n");
      out.write("        <dd>\r\n");
      out.write("        <div class=\"thumb\"><a href=\"\" onclick=\"window.open(this.href); return false\"><img src=\"images/101206.jpg\" alt=\"TITLE04\"></a></div>\r\n");
      out.write("        <div class=\"text\">\r\n");
      out.write("            <h3><a href=\"Login.jsp\">退出</a></h3>\r\n");
      out.write("        </div>\r\n");
      out.write("        </dd>                            \r\n");
      out.write("</dl>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("        var slider2=new accordion.slider(\"slider2\");\r\n");
      out.write("        slider2.init(\"slider2\",0,\"open\");\r\n");
      out.write("\t</script>\r\n");
      out.write(" </div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
