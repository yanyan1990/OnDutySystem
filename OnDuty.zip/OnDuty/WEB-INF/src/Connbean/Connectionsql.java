package Connbean;
//import java.util.*;
import java.sql.*;
public class Connectionsql{
	public static Connection connsql() throws ClassNotFoundException, SQLException{
		String driverClass="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=OnDuty";
		String username="sa";
		String password="123456";
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url,username,password);
		return conn;
	}
	public static void closesql(Connection conn) throws SQLException{
		conn.close();
	}
}